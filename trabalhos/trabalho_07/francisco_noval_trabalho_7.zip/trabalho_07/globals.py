total_produtos = []
total_vendas = []